
package gui;
import principal.RR;
import javax.swing.table.DefaultTableModel;

class Proceso {
    String nombre;
    int tEjecucion;
    int tLlegada;
    int tComienzo;
    int tFinalizacion;

    public Proceso(String nombre, int tiempoEjecucion, int tiempoLlegada) {
        this.nombre = nombre;
        this.tEjecucion = tiempoEjecucion;
        this.tLlegada = tiempoLlegada;
    }
}
public class RoundRobin extends javax.swing.JFrame {
    private DefaultTableModel modeloTabla; 
    private javax.swing.JTextField nombreProceso;
    private javax.swing.JSpinner tiempoEjecucionSpinner;
    private javax.swing.JSpinner tiempoLlegadaSpinner;
    private String[][] dTabla;
    private int indiceProceso;
    
    public RoundRobin() {
        initComponents();
        modeloTabla = new DefaultTableModel();
        
        modeloTabla.addColumn("Proceso");
        modeloTabla.addColumn("Tiempo de Ejecución");
        modeloTabla.addColumn("Tiempo de Llegada");
        modeloTabla.addColumn("Tiempo de Comienzo");
        modeloTabla.addColumn("Tiempo de Finalización");    
        this.tblRegistroRobin.setModel(modeloTabla);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtNombreProceso = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        spinner1 = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        spinner2 = new javax.swing.JSpinner();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblRegistroRobin = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBackground(new java.awt.Color(153, 255, 153));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("ALGORITMO ROUND - ROBIN");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel2.setText("Nombre del proceso:");

        txtNombreProceso.setColumns(20);
        txtNombreProceso.setFont(new java.awt.Font("Monospaced", 0, 18)); // NOI18N
        txtNombreProceso.setRows(5);
        jScrollPane1.setViewportView(txtNombreProceso);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setText("Tiempo de ejecucion(ms):");

        spinner1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        spinner1.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel4.setText("Tiempo de llegada:");

        spinner2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        spinner2.setModel(new javax.swing.SpinnerNumberModel(0, 0, null, 1));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton1.setText("Registrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jButton2.setText("Iniciar Simulacion");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        tblRegistroRobin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(tblRegistroRobin);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(85, 85, 85)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(spinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel4))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(37, 37, 37)
                                        .addComponent(spinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGap(33, 33, 33)
                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 971, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(229, 229, 229)))
                .addGap(80, 80, 80))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(jLabel1)
                .addGap(41, 41, 41)
                .addComponent(jLabel2)
                .addGap(5, 5, 5)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spinner1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(spinner2, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(337, 337, 337))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        ejecutar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Ingresar();
    }//GEN-LAST:event_jButton1ActionPerformed

    public void Ingresar(){
        
        String nombre = this.txtNombreProceso.getText();
        int tiempoEjecucion = (int) this.spinner1.getValue();
        int tiempoLlegada = (int) this.spinner2.getValue();
        Proceso proceso = new Proceso(nombre, tiempoEjecucion, tiempoLlegada);
        Cargar(proceso);
        txtNombreProceso.setText(null);
        spinner1.setValue(0);//Para que al agregar regresen al valor inicial
        spinner2.setValue(0);//Para que al agregar regresen al valor inicial
        txtNombreProceso.grabFocus();
    }
    
    public void Cargar(Proceso proceso)
    {
        String datos[] = new String[5];
        datos[0] = proceso.nombre;
        datos[1] = String.valueOf(proceso.tEjecucion);
        datos[2] = String.valueOf(proceso.tLlegada);
        datos[3] = String.valueOf(proceso.tComienzo);
        datos[4] = String.valueOf(proceso.tFinalizacion);
            
        modeloTabla.addRow(datos);
    }
    
    private void ejecutar() {
            if (modeloTabla.getRowCount() == 0) {
                System.out.println("Agrega al menos un proceso antes de iniciar.");
                return;
            }
            int cantidadProcesos = modeloTabla.getRowCount();
            dTabla = new String[cantidadProcesos][5];
            for (int i = 0; i < cantidadProcesos; i++) {
                dTabla[i][0] = (String) modeloTabla.getValueAt(i, 0);  
                dTabla[i][1] = String.valueOf(modeloTabla.getValueAt(i, 1));
                dTabla[i][2] = String.valueOf(modeloTabla.getValueAt(i, 2));
                dTabla[i][3] = "------";
                dTabla[i][4] = "------";
            }
            RR roundRobin = new RR();
            roundRobin.ejecutarRR(dTabla);
            for (int i = 0; i < cantidadProcesos; i++) {
                modeloTabla.setValueAt(dTabla[i][3], i, 3);
                modeloTabla.setValueAt(dTabla[i][4], i, 4);
            }
            System.out.println("Algoritmo Shortest Job First completado");
        } 
    

    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSpinner spinner1;
    private javax.swing.JSpinner spinner2;
    private javax.swing.JTable tblRegistroRobin;
    private javax.swing.JTextArea txtNombreProceso;
    // End of variables declaration//GEN-END:variables
}
