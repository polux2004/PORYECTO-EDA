package principal;

public class SJF {

    public static void main(String[] args) {
        // Definir los procesos con su tiempo de ejecución y tiempo de llegada
        Proceso[] procesos = new Proceso[]{
                new Proceso("A", 8, 0),
                new Proceso("B", 4, 1),
                new Proceso("C", 9, 2),
                new Proceso("D", 5, 3),
                new Proceso("E", 9, 4)
        };

        // Ordenar los procesos por tiempo de llegada
        ordenarProcesosPorLlegada(procesos);

        // Variables para llevar el seguimiento del tiempo
        int tiempoActual = 0;
        int tiempoTotal = 0;

        // Imprimir la tabla
        System.out.println("Proceso\tTiempo de Ejecución\tTiempo de Llegada\tTiempo de Comienzo\tTiempo de Finalización");
        for (Proceso proceso : procesos) {
            proceso.setTiempoComienzo(tiempoActual);
            proceso.setTiempoFinalizacion(tiempoActual + proceso.getTiempoEjecucion());
            System.out.println(proceso.getNombre() + "\t" + proceso.getTiempoEjecucion() + "\t\t\t" + proceso.getTiempoLlegada() + "\t\t\t" + proceso.getTiempoComienzo() + "\t\t\t" + proceso.getTiempoFinalizacion());
            tiempoActual += proceso.getTiempoEjecucion();
            tiempoTotal += proceso.getTiempoEjecucion();
        }

        // Imprimir el log
        System.out.println("\nLog:");
        tiempoActual = 0;
        while (tiempoActual < tiempoTotal) {
            Proceso procesoActual = null;
            int menorTiempo = Integer.MAX_VALUE;

            // Buscar el proceso con el menor tiempo de ejecución que esté listo para ejecutarse
            for (Proceso proceso : procesos) {
                if (proceso.getTiempoLlegada() <= tiempoActual && !proceso.isEjecutado() && proceso.getTiempoEjecucion() < menorTiempo) {
                    procesoActual = proceso;
                    menorTiempo = proceso.getTiempoEjecucion();
                }
            }

            // Ejecutar el proceso actual
            if (procesoActual != null) {
                procesoActual.setEjecutado(true);
                tiempoActual += procesoActual.getTiempoEjecucion();
                System.out.println("Tiempo " + tiempoActual + ": " + procesoActual.getNombre() + " entra a ejecución");
            } else {
                tiempoActual++;
            }
        }

        System.out.println("Tiempo " + tiempoActual + ": Se ejecutaron todos los procesos.");
    }

    static void ordenarProcesosPorLlegada(Proceso[] procesos) {
        // Implementación de la ordenación (puede usar diferentes algoritmos)
        for (int i = 0; i < procesos.length - 1; i++) {
            for (int j = 0; j < procesos.length - i - 1; j++) {
                if (procesos[j].getTiempoLlegada() > procesos[j + 1].getTiempoLlegada()) {
                    Proceso temp = procesos[j];
                    procesos[j] = procesos[j + 1];
                    procesos[j + 1] = temp;
                }
            }
        }
    }

    static class Proceso {
        private String nombre;
        private int tiempoEjecucion;
        private int tiempoLlegada;
        private int tiempoComienzo;
        private int tiempoFinalizacion;
        private boolean ejecutado;

        public Proceso(String nombre, int tiempoEjecucion, int tiempoLlegada) {
            this.nombre = nombre;
            this.tiempoEjecucion = tiempoEjecucion;
            this.tiempoLlegada = tiempoLlegada;
            this.tiempoComienzo = -1;
            this.tiempoFinalizacion = -1;
            this.ejecutado = false;
        }

        public String getNombre() {
            return nombre;
        }

        public int getTiempoEjecucion() {
            return tiempoEjecucion;
        }

        public int getTiempoLlegada() {
            return tiempoLlegada;
        }

        public int getTiempoComienzo() {
            return tiempoComienzo;
        }

        public void setTiempoComienzo(int tiempoComienzo) {
            this.tiempoComienzo = tiempoComienzo;
        }

        public int getTiempoFinalizacion() {
            return tiempoFinalizacion;
        }

        public void setTiempoFinalizacion(int tiempoFinalizacion) {
            this.tiempoFinalizacion = tiempoFinalizacion;
        }

        public boolean isEjecutado() {
            return ejecutado;
        }

        public void setEjecutado(boolean ejecutado) {
            this.ejecutado = ejecutado;
        }
    }
}
