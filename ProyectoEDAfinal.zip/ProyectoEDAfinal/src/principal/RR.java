package principal;

class Proceso {
    private String nombre;
    private int tEjecucion;
    private int tLlegada;
    private  int tComienzo;
    private int tFinalizacion;

    public Proceso(String nombre, int tEjecucion, int toLlegada) {
        this.nombre = nombre;
        this.tEjecucion = tEjecucion;
        this.tLlegada = tLlegada;
    }
}

public class RR {
    public void ejecutarRR(String[][] dTabla) {
        int quantum = 20;
        int tiempoActual = 0;
        int pActual = 0;
        int pRestantes = dTabla.length;
        for(int i = 0; i< dTabla.length ;i++)
        {
            dTabla[i][3]="0";
        }

        while (pRestantes > 0) {
            String[] proceso = dTabla[pActual];

            if (Integer.parseInt(proceso[1]) > 0) {
                proceso[3] = String.valueOf(tiempoActual);

                if (Integer.parseInt(proceso[1]) <= quantum) {
                    tiempoActual += Integer.parseInt(proceso[1]);
                    proceso[1] = "0";
                    proceso[4] = String.valueOf(tiempoActual);
                    pRestantes--;
                } else {
                    tiempoActual += quantum;
                    proceso[1] = String.valueOf(Integer.parseInt(proceso[1]) - quantum);
                }
            }

            pActual = (pActual + 1) % dTabla.length;
        }
    }

}
